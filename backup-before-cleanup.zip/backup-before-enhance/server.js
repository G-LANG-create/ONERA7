// School Platform backend — run: npm install, then node server.js  (Node 20.12+)
const http = require('http'), fs = require('fs'), crypto = require('crypto'), path = require('path');
const nodemailer = require('nodemailer');
try { process.loadEnvFile(path.join(__dirname, '.env')); } catch {} // hosting services set real env vars instead
const DB = path.join(__dirname, 'db.json');
let db = fs.existsSync(DB) ? JSON.parse(fs.readFileSync(DB)) : { u: [], s: [], n: [], r: [], d: [], f: [], p: [] };
// documents live in one file per institution (see saveDocs); db.json only keeps any whose institution is gone, so none are lost
const save = () => fs.writeFileSync(DB, JSON.stringify({ ...db, d: db.d.filter(x => !db.s.some(s => s.id === x.schoolId)) }, null, 1));
db.a = db.a || []; // older db.json files have no attendance list
db.s.forEach(x => { x.by = x.by || 'Super Admin'; }); // only the main admin can add institutions; older ones have no name or time saved

const SCHOOL_DIR = path.join(__dirname, 'school-data');
const schoolFile = x => path.join(SCHOOL_DIR, `${String(x.name).trim().replace(/[^a-z0-9]+/gi, '-')}-${x.id}.json`);
const saveDocs = x => fs.writeFileSync(schoolFile(x), JSON.stringify({ school: { id: x.id, name: x.name, type: x.type, city: x.city }, docs: db.d.filter(v => v.schoolId === x.id) }, null, 1));
fs.mkdirSync(SCHOOL_DIR, { recursive: true });
db.s.forEach(x => {
  const f = schoolFile(x), old = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f)).docs : [];
  db.d.push(...old.filter(v => !db.d.some(y => y.id === v.id)));
  saveDocs(x); // older db.json files still hold documents: these are moved out by the save() below
});
save();
const id = () => crypto.randomBytes(5).toString('hex');
const hash = (p, s) => crypto.scryptSync(String(p), s, 32).toString('hex');
const mk = (o, p) => { const salt = id(); return { id: id(), ...o, salt, h: hash(p, salt) }; };
const E = (c, m) => { throw { c, m }; };
const sess = {};
const SUB_DAYS = 30, SUB_PRICE = 199;
const PORT = process.env.PORT || 3000;
const OTP_MS = 10 * 6e4, OTP_TRIES = 5, MAIL_GAP_MS = 6e4, PHOTO_MAX = 300 * 1024;

const smtpPort = +process.env.SMTP_PORT || 465;
const mailer = process.env.SMTP_USER && nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com', port: smtpPort, secure: smtpPort === 465,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});
const sendMail = (to, subject, text) => {
  if (!mailer) return console.log(`[email not configured] To ${to}: ${subject}\n${text}`);
  mailer.sendMail({ from: `ONERA <${process.env.SMTP_USER}>`, to, subject, text }).catch(e => console.error('Email failed:', e.message));
};
// one email per minute per address + type, so the public forms cannot be used to flood an inbox
const lastMail = {};
const tooSoon = k => { if (lastMail[k] > Date.now() - MAIL_GAP_MS) return true; lastMail[k] = Date.now(); };

const sha = t => crypto.createHash('sha256').update(String(t)).digest('hex');
// email codes: only the hash is kept, and a few wrong guesses cancel the code
const otps = {};
const newOtp = k => {
  const c = String(crypto.randomInt(1e6)).padStart(6, '0');
  otps[k] = { h: sha(k + c), x: Date.now() + OTP_MS, n: 0 };
  return c;
};
const useOtp = (k, c) => {
  const o = otps[k], live = o && o.x > Date.now() && ++o.n <= OTP_TRIES;
  if (live && o.h === sha(k + String(c || '').trim())) return delete otps[k];
  if (o && (!live || o.n === OTP_TRIES)) delete otps[k];
  E(400, 'Wrong or expired code');
};
const cleanEmail = e => {
  const v = String(e || '').trim().toLowerCase();
  if (v && !/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(v)) E(400, 'Enter a valid email address');
  return v || undefined;
};

if (!db.u.length) { db.u.push(mk({ role: 'admin', name: 'Super Admin', username: 'admin' }, 'admin123')); save(); }

const pub = x => ({ id: x.id, role: x.role, name: x.name, username: x.username, schoolId: x.schoolId, cls: x.cls, sub: x.sub });
const isCollege = sId => (db.s.find(v => v.id === sId) || {}).type === 'College';
const self = x => ({ ...pub(x), email: x.email, photo: x.photo, college: isCollege(x.schoolId) }); // email and photo go only to their owner
// schools run classes 1-10, colleges semesters 1-8; both are stored in cls
const checkCls = (c, sId) => { const n = isCollege(sId) ? ['Semester', 8] : ['Class', 10]; if (!(c >= 1 && c <= n[1])) E(400, `${n[0]} must be 1-${n[1]}`); };

function handle(m, p, q, b, u) {
  const k = m + ' ' + p, sid = u && u.schoolId;
  const need = (...r) => { if (!u) E(401, 'Please login first'); if (r.length && !r.includes(u.role)) E(403, 'Not allowed'); };
  const mine = sId => { const s = db.u.find(v => v.id === sId && v.schoolId === sid && v.role === 'student'); if (!s) E(400, 'Student not found in your school'); return s; };
  const nameOf = x => (db.u.find(v => v.id === x.studentId) || {}).name;

  // ---- public ----
  if (k === 'GET schools') { // who added an institution and when goes only to the main admin
    const s = (q.get('q') || '').toLowerCase(), admin = u && u.role === 'admin';
    return db.s.filter(x => (x.name + ' ' + x.city + ' ' + x.type).toLowerCase().includes(s)).map(x => admin ? x : { id: x.id, name: x.name, type: x.type, city: x.city });
  }
  if (k === 'POST login') {
    const x = db.u.find(v => v.username === b.username);
    if (!x || hash(b.password || '', x.salt) !== x.h) E(401, 'Wrong username or password');
    const t = id() + id(); sess[t] = x.id; return { token: t, user: self(x) };
  }
  if (k === 'GET me') { need(); return self(u); }
  if (k === 'POST email') {
    need(); const e = cleanEmail(b.email); if (!e) E(400, 'Enter a valid email address');
    u.email = e; save(); return self(u);
  }
  if (k === 'POST photo') { // the page shrinks the picture first, so anything big here is not from it
    need();
    if (b.photoData) {
      if (!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(b.photoData)) E(400, 'Photo must be a JPEG image');
      if (b.photoData.length > PHOTO_MAX) E(400, 'Photo is too large');
      u.photo = b.photoData;
    } else delete u.photo;
    save(); return self(u);
  }

  // ---- forgot username / password: same reply either way, so nobody can test which accounts exist ----
  if (k === 'POST forgot-username') {
    const e = cleanEmail(b.email), list = db.u.filter(v => e && v.email === e);
    if (list.length && !tooSoon('u:' + e)) sendMail(e, 'Your ONERA verification code', `Your code to see your username is ${newOtp('u:' + e)}\n\nIt expires in 10 minutes. If you did not ask for this, ignore this email.`);
    return { ok: 1 };
  }
  if (k === 'POST verify-username') {
    const e = cleanEmail(b.email);
    useOtp('u:' + e, b.code);
    return { usernames: db.u.filter(v => v.email === e).map(v => v.username) };
  }
  if (k === 'POST forgot-password') {
    const x = db.u.find(v => v.username === b.username);
    if (x && x.email && !tooSoon('p:' + x.id)) sendMail(x.email, 'Your ONERA verification code', `Your code to reset the password for "${x.username}" is ${newOtp('p:' + x.id)}\n\nIt expires in 10 minutes. If you did not ask for this, ignore this email.`);
    return { ok: 1 };
  }
  if (k === 'POST reset-password') {
    const x = db.u.find(v => v.username === b.username);
    if (String(b.password || '').length < 6) E(400, 'Password must be at least 6 characters');
    useOtp('p:' + (x && x.id), b.code);
    x.salt = id(); x.h = hash(b.password, x.salt);
    Object.keys(sess).forEach(t => { if (sess[t] === x.id) delete sess[t]; }); // logs out any stolen session
    save(); return { ok: 1 };
  }

  // ---- main admin: add schools / colleges ----
  if (k === 'POST schools') {
    need('admin');
    if (!b.name || !b.username || !b.password) E(400, 'Fill all fields');
    if (db.u.some(v => v.username === b.username)) E(400, 'Username already taken');
    const email = cleanEmail(b.email);
    const s = { id: id(), name: b.name, type: b.type, city: b.city, by: u.name, at: Date.now() }; db.s.push(s);
    db.u.push(mk({ role: 'school', name: b.name + ' (Admin)', username: b.username, email, schoolId: s.id }, b.password));
    saveDocs(s); save(); return s;
  }

  if (k === 'GET school-stats') { // totals only: the main admin never gets student names or document photos
    need('admin');
    return db.s.map(x => {
      const of = r => db.u.filter(v => v.schoolId === x.id && v.role === r).length, students = of('student');
      const fees = db.f.filter(v => v.schoolId === x.id).map(v => ({ amount: v.amount, paid: db.p.filter(y => y.f === v.id).length }));
      return {
        id: x.id, students, teachers: of('teacher'),
        docs: db.d.filter(v => v.schoolId === x.id).length,
        collected: fees.reduce((s, v) => s + v.amount * v.paid, 0),
        pending: fees.reduce((s, v) => s + v.amount * Math.max(students - v.paid, 0), 0)
      };
    });
  }

  // ---- school admin: teachers & students ----
  if (k === 'POST users') {
    need('school');
    if (!['teacher', 'student'].includes(b.role)) E(400, 'Invalid role');
    if (db.u.some(v => v.username === b.username)) E(400, 'Username already taken');
    const c = +b.cls; if (b.role === 'student') checkCls(c, sid);
    db.u.push(mk({ role: b.role, name: b.name, username: b.username, email: cleanEmail(b.email), schoolId: sid, cls: b.role === 'student' ? c : null }, b.password));
    save(); return { ok: 1 };
  }
  if (k === 'GET users') { need('school', 'teacher'); return db.u.filter(v => v.schoolId === sid && (v.role === 'student' || v.role === 'teacher')).map(pub); }

  // ---- notes (paid) ----
  if (k === 'POST notes') {
    need('teacher'); const c = +b.cls; checkCls(c, sid);
    db.n.push({ id: id(), schoolId: sid, cls: c, title: b.title, content: b.content, by: u.name, at: Date.now() }); save(); return { ok: 1 };
  }
  if (k === 'GET notes') {
    need('teacher', 'student', 'school');
    if (u.role === 'student') {
      const ok = (u.sub || 0) > Date.now();
      return { subscribed: ok, price: SUB_PRICE, items: db.n.filter(x => x.schoolId === sid && x.cls === u.cls).map(x => ({ ...x, content: ok ? x.content : null })) };
    }
    return { items: db.n.filter(x => x.schoolId === sid) };
  }
  if (k === 'POST subscribe') { need('student'); u.sub = Math.max(u.sub || 0, Date.now()) + SUB_DAYS * 864e5; save(); return self(u); } // demo: plug a payment gateway here

  // ---- results ----
  if (k === 'POST results') {
    need('school', 'teacher'); mine(b.studentId);
    db.r.push({ id: id(), schoolId: sid, studentId: b.studentId, exam: b.exam, subject: b.subject, marks: +b.marks, total: +b.total }); save(); return { ok: 1 };
  }
  if (k === 'GET results') {
    need('school', 'teacher', 'student');
    return (u.role === 'student' ? db.r.filter(x => x.studentId === u.id) : db.r.filter(x => x.schoolId === sid)).map(x => ({ ...x, student: nameOf(x) }));
  }

  // ---- monthly attendance ----
  if (k === 'POST attendance') {
    need('school', 'teacher'); mine(b.studentId);
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(b.month)) E(400, 'Choose a valid month');
    const [y, mo] = b.month.split('-').map(Number), d = b.day, at = new Date(y, mo - 1, d);
    if (!Number.isInteger(d) || d < 1 || d > new Date(y, mo, 0).getDate()) E(400, 'Choose a valid date');
    if (at.getDay() === 0) E(400, 'Sunday is a holiday');
    if (at > Date.now() + 864e5) E(400, 'Cannot mark a future date'); // 1 day margin: server may be in another timezone
    let x = db.a.find(v => v.studentId === b.studentId && v.month === b.month);
    if (!x) { x = { id: id(), schoolId: sid, studentId: b.studentId, month: b.month }; db.a.push(x); }
    x.days = (x.days || []).filter(v => v !== d);
    if (b.present) x.days.push(d);
    x.days.sort((p, q) => p - q);
    save(); return { ok: 1 };
  }
  if (k === 'GET attendance') {
    need('school', 'teacher', 'student');
    return (u.role === 'student' ? db.a.filter(x => x.studentId === u.id) : db.a.filter(x => x.schoolId === sid)).map(x => ({ ...x, days: x.days || [], student: nameOf(x) }));
  }

  // ---- student documents (govt IDs etc.) ----
  if (k === 'POST docs') {
    need('school'); mine(b.studentId);
    if (!b.type || !b.photoData) E(400, 'Choose a document type and upload a photo');
    const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(b.photoData);
    if (!match) E(400, 'Photo must be JPG, PNG or WebP');
    if (Buffer.from(match[2], 'base64').length > 3 * 1024 * 1024) E(400, 'Photo must be 3 MB or smaller');
    db.d.push({ id: id(), schoolId: sid, studentId: b.studentId, type: b.type, photoData: b.photoData });
    saveDocs(db.s.find(v => v.id === sid)); return { ok: 1 };
  }
  if (k === 'GET docs') {
    need('school', 'student');
    return (u.role === 'student' ? db.d.filter(x => x.studentId === u.id) : db.d.filter(x => x.schoolId === sid)).map(x => ({ ...x, student: nameOf(x) }));
  }

  // ---- fees / payments ----
  if (k === 'POST fees') { need('school'); db.f.push({ id: id(), schoolId: sid, title: b.title, amount: +b.amount, dueDate: b.dueDate }); save(); return { ok: 1 }; }
  if (k === 'GET fees') {
    need('school', 'student');
    return db.f.filter(x => x.schoolId === sid).map(x => u.role === 'student' ? { ...x, paid: db.p.some(y => y.s === u.id && y.f === x.id) } : { ...x, paidCount: db.p.filter(y => y.f === x.id).length });
  }
  if (k === 'POST pay') {
    need('student'); const f = db.f.find(x => x.id === b.feeId && x.schoolId === sid); if (!f) E(404, 'Fee not found');
    if (!db.p.some(y => y.s === u.id && y.f === f.id)) { db.p.push({ s: u.id, f: f.id, at: Date.now() }); save(); } return { ok: 1 };
  }
  E(404, 'Not found');
}

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x'); let body = '';
  req.on('data', d => {
    body += d;
    if (body.length > 5 * 1024 * 1024) { res.writeHead(413, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: 'Request too large. Choose an image under 3 MB.' })); req.destroy(); }
  });
  req.on('end', () => {
    if (url.pathname === '/logo.png') { res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'max-age=86400' }); return res.end(fs.readFileSync(path.join(__dirname, 'logo.png'))); }
    if (!url.pathname.startsWith('/api/')) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(fs.readFileSync(path.join(__dirname, 'index.html'))); }
    const send = (c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
    try {
      const u = db.u.find(x => x.id === sess[req.headers.authorization]);
      send(200, handle(req.method, url.pathname.slice(5), url.searchParams, body ? JSON.parse(body) : {}, u));
    } catch (e) { send(e.c || 400, { error: e.m || e.message }); }
  });
}).listen(PORT, () => console.log('Running on http://localhost:' + PORT + '  (admin / admin123)' + (mailer ? '' : '\nEmail is NOT configured: see .env.example')));
