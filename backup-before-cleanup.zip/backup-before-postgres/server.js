// School Platform backend — run: npm install, then node server.js  (Node 20.12+)
const http = require('http'), https = require('https'), fs = require('fs'), crypto = require('crypto'), path = require('path');
const nodemailer = require('nodemailer');
try { process.loadEnvFile(path.join(__dirname, '.env')); } catch {} // hosting services set real env vars instead
// db.json and the school files are AES-256-GCM encrypted on disk; in memory they stay plain, so the code below never deals with it
const KEY = Buffer.from(process.env.DATA_KEY || '', 'hex'), SEALED = 'onera-aes256gcm:';
if (KEY.length !== 32) { console.error('DATA_KEY must be set to 64 hex characters: see .env.example'); process.exit(1); }
const seal = t => {
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', KEY, iv), data = Buffer.concat([c.update(t), c.final()]);
  return SEALED + Buffer.concat([iv, c.getAuthTag(), data]).toString('base64');
};
const unseal = f => { // files from before encryption are still plain: they are sealed by the saves at startup
  const t = String(fs.readFileSync(f));
  if (!t.startsWith(SEALED)) return t;
  try {
    const b = Buffer.from(t.slice(SEALED.length), 'base64'), d = crypto.createDecipheriv('aes-256-gcm', KEY, b.subarray(0, 12));
    d.setAuthTag(b.subarray(12, 28));
    return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString();
  } catch { console.error(`Cannot decrypt ${f}: wrong DATA_KEY or a damaged file`); process.exit(1); }
};
const DB = path.join(__dirname, 'db.json');
let db = fs.existsSync(DB) ? JSON.parse(unseal(DB)) : { u: [], s: [], n: [], r: [], d: [], f: [], p: [] };
// documents live in one file per institution (see saveDocs); db.json only keeps any whose institution is gone, so none are lost
const save = () => fs.writeFileSync(DB, seal(JSON.stringify({ ...db, d: db.d.filter(x => !db.s.some(s => s.id === x.schoolId)) }, null, 1)));
db.a = db.a || []; // older db.json files have no attendance list
db.b = db.b || []; // nor a notice board
db.t = db.t || []; // nor a timetable
db.h = db.h || []; // nor homework
db.s.forEach(x => { x.by = x.by || 'Super Admin'; }); // only the main admin can add institutions; older ones have no name or time saved

const SCHOOL_DIR = path.join(__dirname, 'school-data');
const schoolFile = x => path.join(SCHOOL_DIR, `${String(x.name).trim().replace(/[^a-z0-9]+/gi, '-')}-${x.id}.json`);
const saveDocs = x => fs.writeFileSync(schoolFile(x), seal(JSON.stringify({ school: { id: x.id, name: x.name, type: x.type, city: x.city }, docs: db.d.filter(v => v.schoolId === x.id) }, null, 1)));
// files attached to notes stay on disk, so they never slow down the db.json saves
const NOTE_DIR = path.join(__dirname, 'note-files');
const NOTE_FILES = 20, NOTE_FILES_MAX = 10 * 1024 * 1024;
fs.mkdirSync(NOTE_DIR, { recursive: true });
fs.mkdirSync(SCHOOL_DIR, { recursive: true });
db.s.forEach(x => {
  const f = schoolFile(x), old = fs.existsSync(f) ? JSON.parse(unseal(f)).docs : [];
  db.d.push(...old.filter(v => !db.d.some(y => y.id === v.id)));
  saveDocs(x); // older db.json files still hold documents: these are moved out by the save() below
});
save();
const id = () => crypto.randomBytes(5).toString('hex');
const hash = (p, s) => crypto.scryptSync(String(p), s, 32).toString('hex');
const mk = (o, p) => { const salt = id(); return { id: id(), ...o, salt, h: hash(p, salt) }; };
const E = (c, m) => { throw { c, m }; };
const sess = {};
const SUB_DAYS = 30, SUB_PRICE = 199;
const PORT = process.env.PORT || 3000;
const OTP_MS = 10 * 6e4, OTP_TRIES = 5, MAIL_GAP_MS = 6e4, PHOTO_MAX = 300 * 1024;

const smtpPort = +process.env.SMTP_PORT || 465;
const mailer = process.env.SMTP_USER && nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com', port: smtpPort, secure: smtpPort === 465,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
});
const sendMail = (to, subject, text) => {
  if (!mailer) return console.log(`[email not configured] To ${to}: ${subject}\n${text}`);
  mailer.sendMail({ from: `ONERA <${process.env.SMTP_USER}>`, to, subject, text }).catch(e => console.error('Email failed:', e.message));
};
// one email per minute per address + type, so the public forms cannot be used to flood an inbox
const lastMail = {};
const tooSoon = k => { if (lastMail[k] > Date.now() - MAIL_GAP_MS) return true; lastMail[k] = Date.now(); };

const sha = t => crypto.createHash('sha256').update(String(t)).digest('hex');
// email codes: only the hash is kept, and a few wrong guesses cancel the code
const otps = {};
const newOtp = k => {
  const c = String(crypto.randomInt(1e6)).padStart(6, '0');
  otps[k] = { h: sha(k + c), x: Date.now() + OTP_MS, n: 0 };
  return c;
};
const useOtp = (k, c) => {
  const o = otps[k], live = o && o.x > Date.now() && ++o.n <= OTP_TRIES;
  if (live && o.h === sha(k + String(c || '').trim())) return delete otps[k];
  if (o && (!live || o.n === OTP_TRIES)) delete otps[k];
  E(400, 'Wrong or expired code');
};
const cleanEmail = e => {
  const v = String(e || '').trim().toLowerCase();
  if (v && !/^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(v)) E(400, 'Enter a valid email address');
  return v || undefined;
};

if (!db.u.length) { db.u.push(mk({ role: 'admin', name: 'Super Admin', username: 'admin' }, 'admin123')); save(); }

const pub = x => ({ id: x.id, role: x.role, name: x.name, username: x.username, schoolId: x.schoolId, cls: x.cls, classes: x.classes, sub: x.sub });
const isCollege = sId => (db.s.find(v => v.id === sId) || {}).type === 'College';
const self = x => ({ ...pub(x), email: x.email, photo: x.photo, college: isCollege(x.schoolId), school: (db.s.find(v => v.id === x.schoolId) || {}).name }); // email and photo go only to their owner
// schools run classes 1-10 with sections A-C (stored like '5-A'), colleges semesters 1-8 (stored like 3); both are stored in cls
const SECTIONS = ['A', 'B', 'C'];
const classList = sId => isCollege(sId) ? [...Array(8)].map((_, i) => i + 1) : [...Array(10)].flatMap((_, i) => SECTIONS.map(v => `${i + 1}-${v}`));
const cleanCls = (c, sId) => { const v = isCollege(sId) ? +c : String(c); if (!classList(sId).includes(v)) E(400, isCollege(sId) ? 'Semester must be 1-8' : 'Choose a class from 1-A to 10-C'); return v; };
// the classes a teacher teaches: stored sorted, without repeats
const cleanClasses = (list, sId) => { const on = [].concat(list || []).map(v => cleanCls(v, sId)); return classList(sId).filter(v => on.includes(v)); };
// older school records have only a class number: students and notes go to section A, teachers keep every section of their classes
const oldCls = [...db.u, ...db.n].filter(x => typeof x.cls === 'number' && !isCollege(x.schoolId));
const oldClasses = db.u.filter(x => (x.classes || []).some(v => typeof v === 'number') && !isCollege(x.schoolId));
if (oldCls.length || oldClasses.length) {
  fs.copyFileSync(DB, DB + '.before-sections');
  oldCls.forEach(x => { x.cls += '-A'; });
  oldClasses.forEach(x => { x.classes = x.classes.flatMap(c => SECTIONS.map(v => `${c}-${v}`)); });
  save();
}
// every April school students move up a class and class 10 passes out; colleges keep their semesters. db.promoted is the last April done
const PASSED = 'Passed out';
const aprilYear = () => { const d = new Date(); return d.getFullYear() - (d.getMonth() < 3 ? 1 : 0); };
if (!db.promoted) { db.promoted = aprilYear(); save(); } // a first run only records the year, so nobody moves early
const promote = () => {
  const y = aprilYear();
  if (db.promoted >= y) return;
  fs.copyFileSync(DB, `${DB}.before-promotion-${y}`);
  db.u.filter(v => v.role === 'student' && !isCollege(v.schoolId)).forEach(v => {
    const c = /^(\d+)-([A-C])$/.exec(v.cls);
    if (c) v.cls = +c[1] >= 10 ? PASSED : `${+c[1] + 1}-${c[2]}`;
  });
  db.promoted = y; save();
  console.log(`Classes promoted for April ${y}`);
};
promote(); // also catches up if the server was off on 1 April
setInterval(promote, 36e5);
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], CLOCK = /^([01]\d|2[0-3]):[0-5]\d$/;
// profile details: every field is optional, the email in the form is the same recovery email as u.email
const GENDERS = ['Male', 'Female', 'Other'], BLOOD = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const cleanPhone = v => { const t = String(v || '').trim(); if (t && !/^\+?[0-9][0-9 -]{6,18}$/.test(t)) E(400, 'Enter a valid phone number'); return t; };
const cleanProfile = b => {
  const p = { phone: cleanPhone(b.phone), altPhone: cleanPhone(b.altPhone) };
  ['address', 'mother', 'father', 'birthPlace', 'citizenship', 'religion'].forEach(k => { p[k] = String(b[k] || '').trim().slice(0, 300); });
  p.dob = String(b.dob || '');
  if (p.dob && (!/^\d{4}-\d{2}-\d{2}$/.test(p.dob) || isNaN(new Date(p.dob)) || new Date(p.dob) > Date.now())) E(400, 'Choose a valid date of birth');
  p.gender = GENDERS.includes(b.gender) ? b.gender : '';
  p.blood = BLOOD.includes(b.blood) ? b.blood : '';
  return p;
};
// a new password also logs out every session, so a stolen one stops working
const setPassword = (x, p) => {
  x.salt = id(); x.h = hash(p, x.salt);
  Object.keys(sess).forEach(t => { if (sess[t] === x.id) delete sess[t]; });
  save();
};
// one date for one student: shared by the calendar and the class register
const setDay = (sid, studentId, month, d, present) => {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) E(400, 'Choose a valid month');
  const [y, mo] = month.split('-').map(Number), at = new Date(y, mo - 1, d);
  if (!Number.isInteger(d) || d < 1 || d > new Date(y, mo, 0).getDate()) E(400, 'Choose a valid date');
  if (at.getDay() === 0) E(400, 'Sunday is a holiday');
  if (at > Date.now() + 864e5) E(400, 'Cannot mark a future date'); // 1 day margin: server may be in another timezone
  let x = db.a.find(v => v.studentId === studentId && v.month === month);
  if (!x) { x = { id: id(), schoolId: sid, studentId, month }; db.a.push(x); }
  x.days = (x.days || []).filter(v => v !== d);
  if (present) x.days.push(d);
  x.days.sort((p, q) => p - q);
};

function handle(m, p, q, b, u) {
  const k = m + ' ' + p, sid = u && u.schoolId;
  const need = (...r) => { if (!u) E(401, 'Please login first'); if (r.length && !r.includes(u.role)) E(403, 'Not allowed'); };
  // teachers only reach their own classes; everyone else passes
  const taught = c => u.role !== 'teacher' || (u.classes || []).includes(c);
  const sees = x => taught((db.u.find(v => v.id === x.studentId) || {}).cls);
  const mine = sId => { const s = db.u.find(v => v.id === sId && v.schoolId === sid && v.role === 'student'); if (!s) E(400, 'Student not found in your school'); if (!taught(s.cls)) E(403, 'This student is not in your classes'); return s; };
  const nameOf = x => (db.u.find(v => v.id === x.studentId) || {}).name;

  // ---- public ----
  if (k === 'GET schools') { // who added an institution and when goes only to the main admin
    const s = (q.get('q') || '').toLowerCase(), admin = u && u.role === 'admin';
    return db.s.filter(x => (x.name + ' ' + x.city + ' ' + x.type).toLowerCase().includes(s)).map(x => admin ? x : { id: x.id, name: x.name, type: x.type, city: x.city });
  }
  if (k === 'POST login') {
    const x = db.u.find(v => v.username === b.username);
    // school logins only work on their own school's page; the main admin has no school
    if (!x || hash(b.password || '', x.salt) !== x.h || (x.schoolId || '') !== (b.schoolId || '')) E(401, 'Wrong username or password');
    const t = id() + id(); sess[t] = x.id; return { token: t, user: self(x) };
  }
  if (k === 'GET me') { need(); return self(u); }
  if (k === 'POST password') {
    need();
    if (hash(b.old || '', u.salt) !== u.h) E(400, 'Current password is wrong');
    if (String(b.password || '').length < 6) E(400, 'Password must be at least 6 characters');
    setPassword(u, b.password); return { ok: 1 };
  }
  if (k === 'POST photo') { // the page shrinks the picture first, so anything big here is not from it
    need();
    if (b.photoData) {
      if (!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(b.photoData)) E(400, 'Photo must be a JPEG image');
      if (b.photoData.length > PHOTO_MAX) E(400, 'Photo is too large');
      u.photo = b.photoData;
    } else delete u.photo;
    save(); return self(u);
  }

  // ---- profile: your own, or a school admin's own teachers and students. Not in self(), because the login is kept in localStorage ----
  if (k === 'GET profile' || k === 'POST profile') {
    need();
    const x = q.get('id') || b.id ? db.u.find(v => v.id === (q.get('id') || b.id) && v.schoolId === sid && u.role === 'school' && ['teacher', 'student'].includes(v.role)) : u;
    if (!x) E(404, 'Person not found');
    if (m === 'POST') { const p = cleanProfile(b); x.email = cleanEmail(b.email); x.profile = p; save(); }
    return { ...self(x), profile: x.profile || {} };
  }

  // ---- forgot username / password: same reply either way, so nobody can test which accounts exist ----
  if (k === 'POST forgot-username') {
    const e = cleanEmail(b.email), list = db.u.filter(v => e && v.email === e);
    if (list.length && !tooSoon('u:' + e)) sendMail(e, 'Your ONERA verification code', `Your code to see your username is ${newOtp('u:' + e)}\n\nIt expires in 10 minutes. If you did not ask for this, ignore this email.`);
    return { ok: 1 };
  }
  if (k === 'POST verify-username') {
    const e = cleanEmail(b.email);
    useOtp('u:' + e, b.code);
    return { usernames: db.u.filter(v => v.email === e).map(v => v.username) };
  }
  if (k === 'POST forgot-password') {
    const x = db.u.find(v => v.username === b.username);
    // many students have no inbox of their own, so their code goes to their school admin, who passes it on
    const adminEmail = x && x.role === 'student' && (db.u.find(v => v.role === 'school' && v.schoolId === x.schoolId) || {}).email;
    const to = adminEmail || (x && x.email);
    if (to && !tooSoon('p:' + x.id)) sendMail(to, adminEmail ? `Password reset code for student ${x.name}` : 'Your ONERA verification code', adminEmail
      ? `${x.name} (username "${x.username}", class ${x.cls}) asked to reset their password. The code is ${newOtp('p:' + x.id)}\n\nIt expires in 10 minutes. Give it to the student only after checking it is really them. If nobody asked for this, ignore this email.`
      : `Your code to reset the password for "${x.username}" is ${newOtp('p:' + x.id)}\n\nIt expires in 10 minutes. If you did not ask for this, ignore this email.`);
    return { ok: 1 };
  }
  if (k === 'POST reset-password') {
    const x = db.u.find(v => v.username === b.username);
    if (String(b.password || '').length < 6) E(400, 'Password must be at least 6 characters');
    useOtp('p:' + (x && x.id), b.code);
    setPassword(x, b.password); return { ok: 1 };
  }

  // ---- main admin: add schools / colleges ----
  if (k === 'POST schools') {
    need('admin');
    if (!b.name || !b.username || !b.password) E(400, 'Fill all fields');
    if (db.u.some(v => v.username === b.username)) E(400, 'Username already taken');
    const email = cleanEmail(b.email);
    const s = { id: id(), name: b.name, type: b.type, city: b.city, by: u.name, at: Date.now() }; db.s.push(s);
    db.u.push(mk({ role: 'school', name: b.name + ' (Admin)', username: b.username, email, schoolId: s.id }, b.password));
    saveDocs(s); save(); return s;
  }

  if (k === 'GET school-stats') { // totals only: the main admin never gets student names or document photos
    need('admin');
    return db.s.map(x => {
      const of = r => db.u.filter(v => v.schoolId === x.id && v.role === r && v.cls !== PASSED).length, students = of('student');
      const fees = db.f.filter(v => v.schoolId === x.id).map(v => ({ amount: v.amount, paid: db.p.filter(y => y.f === v.id).length }));
      return {
        id: x.id, students, teachers: of('teacher'),
        docs: db.d.filter(v => v.schoolId === x.id).length,
        collected: fees.reduce((s, v) => s + v.amount * v.paid, 0),
        pending: fees.reduce((s, v) => s + v.amount * Math.max(students - v.paid, 0), 0)
      };
    });
  }

  // ---- school admin: teachers & students ----
  if (k === 'POST users') {
    need('school');
    if (!['teacher', 'student'].includes(b.role)) E(400, 'Invalid role');
    if (db.u.some(v => v.username === b.username)) E(400, 'Username already taken');
    const c = b.role === 'student' ? cleanCls(b.cls, sid) : null;
    const classes = b.role === 'teacher' ? cleanClasses(b.classes, sid) : undefined;
    db.u.push(mk({ role: b.role, name: b.name, username: b.username, email: cleanEmail(b.email), schoolId: sid, cls: c, classes }, b.password));
    save(); return { ok: 1 };
  }
  if (k === 'POST teacher-classes') {
    need('school');
    const x = db.u.find(v => v.id === b.id && v.schoolId === sid && v.role === 'teacher');
    if (!x) E(404, 'Teacher not found');
    x.classes = cleanClasses(b.classes, sid); save(); return { ok: 1 };
  }
  if (k === 'POST remove-user') { // a student's records go with them; a teacher's notes and notices stay for the school
    need('school');
    const x = db.u.find(v => v.id === b.id && v.schoolId === sid && ['teacher', 'student'].includes(v.role));
    if (!x) E(404, 'Person not found');
    db.u = db.u.filter(v => v !== x);
    Object.keys(sess).forEach(t => { if (sess[t] === x.id) delete sess[t]; });
    if (x.role === 'student') {
      db.r = db.r.filter(v => v.studentId !== x.id);
      db.a = db.a.filter(v => v.studentId !== x.id);
      db.p = db.p.filter(v => v.s !== x.id);
      db.d = db.d.filter(v => v.studentId !== x.id);
      saveDocs(db.s.find(v => v.id === sid));
    }
    save(); return { ok: 1 };
  }
  if (k === 'GET users') { // a teacher gets only the students of their classes
    need('school', 'teacher');
    return db.u.filter(v => v.schoolId === sid && (v.role === 'student' ? taught(v.cls) : v.role === 'teacher' && u.role === 'school')).map(pub);
  }

  // ---- notice board ----
  if (k === 'POST notices') {
    need('school', 'teacher');
    if (!b.title || !b.body) E(400, 'Fill all fields');
    db.b.push({ id: id(), schoolId: sid, title: b.title, body: b.body, by: u.name, at: Date.now() }); save(); return { ok: 1 };
  }
  if (k === 'GET notices') { need('school', 'teacher', 'student'); return db.b.filter(x => x.schoolId === sid).reverse(); }

  // ---- timetable: the school admin sets it, teachers and students only see their classes ----
  if (k === 'POST timetable') {
    need('school');
    const c = cleanCls(b.cls, sid), subject = String(b.subject || '').trim().slice(0, 100);
    if (!DAYS.includes(b.day)) E(400, 'Choose a day');
    if (!subject) E(400, 'Enter a subject');
    if (!CLOCK.test(b.start) || !CLOCK.test(b.end) || b.start >= b.end) E(400, 'End time must be after start time');
    const t = b.teacherId && db.u.find(v => v.id === b.teacherId && v.schoolId === sid && v.role === 'teacher');
    if (b.teacherId && !(t && (t.classes || []).includes(c))) E(400, 'That teacher does not teach this class');
    const busy = x => x.schoolId === sid && x.day === b.day && x.start < b.end && b.start < x.end;
    if (db.t.some(x => busy(x) && x.cls === c)) E(400, 'This class already has a period at that time');
    if (t && db.t.some(x => busy(x) && x.teacherId === t.id)) E(400, `${t.name} already has a period at that time`);
    db.t.push({ id: id(), schoolId: sid, cls: c, day: b.day, start: b.start, end: b.end, subject, teacherId: t ? t.id : undefined });
    save(); return { ok: 1 };
  }
  if (k === 'GET timetable') {
    need('school', 'teacher', 'student');
    return db.t.filter(x => x.schoolId === sid && (u.role === 'student' ? x.cls === u.cls : taught(x.cls))).map(x => ({ ...x, teacher: (db.u.find(v => v.id === x.teacherId) || {}).name }));
  }

  // ---- homework: free for students, unlike notes ----
  if (k === 'POST homework') {
    need('teacher'); const c = cleanCls(b.cls, sid);
    if (!taught(c)) E(403, 'You do not teach this class');
    if (!b.subject || !b.details) E(400, 'Fill all fields');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(b.due) || isNaN(new Date(b.due))) E(400, 'Choose a valid due date');
    db.h.push({ id: id(), schoolId: sid, cls: c, subject: b.subject, details: b.details, due: b.due, by: u.name, at: Date.now() }); save(); return { ok: 1 };
  }
  if (k === 'GET homework') {
    need('school', 'teacher', 'student');
    return db.h.filter(x => x.schoolId === sid && (u.role === 'student' ? x.cls === u.cls : taught(x.cls))).reverse();
  }

  // ---- delete a record: teachers cannot touch fees, documents or the timetable ----
  if (k === 'POST remove') {
    need('school', 'teacher');
    const list = { notices: db.b, notes: db.n, results: db.r, fees: db.f, docs: db.d, homework: db.h, periods: db.t }[b.kind];
    if (!list || (u.role === 'teacher' && ['fees', 'docs', 'periods'].includes(b.kind))) E(403, 'Not allowed');
    const i = list.findIndex(v => v.id === b.id && v.schoolId === sid);
    if (i < 0) E(404, 'Not found');
    if (((b.kind === 'notes' || b.kind === 'homework') && !taught(list[i].cls)) || (b.kind === 'results' && !sees(list[i]))) E(403, 'Not allowed');
    const [gone] = list.splice(i, 1);
    if (b.kind === 'notes') (gone.files || []).forEach(v => fs.rmSync(path.join(NOTE_DIR, v.id), { force: true }));
    if (b.kind === 'fees') db.p = db.p.filter(y => y.f !== b.id);
    if (b.kind === 'docs') saveDocs(db.s.find(v => v.id === sid));
    save(); return { ok: 1 };
  }

  // ---- notes (paid) ----
  if (k === 'POST notes') {
    need('teacher'); const c = cleanCls(b.cls, sid);
    if (!taught(c)) E(403, 'You do not teach this class');
    const list = Array.isArray(b.files) ? b.files : [];
    if (!b.title || !(b.content || list.length)) E(400, 'Add a title, then write notes or attach a file');
    if (list.length > NOTE_FILES) E(400, `Attach up to ${NOTE_FILES} files`);
    const files = list.map(f => {
      const match = /^data:(application\/pdf|image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(f.data);
      if (!match) E(400, 'Files must be PDF, JPG, PNG or WebP');
      return { id: id(), name: String(f.name || 'file').slice(0, 120), type: match[1], buf: Buffer.from(match[2], 'base64') };
    });
    if (files.reduce((s, v) => s + v.buf.length, 0) > NOTE_FILES_MAX) E(400, 'Files must be 10 MB or smaller in total');
    files.forEach(v => { fs.writeFileSync(path.join(NOTE_DIR, v.id), v.buf); delete v.buf; });
    db.n.push({ id: id(), schoolId: sid, cls: c, title: b.title, content: b.content, files, by: u.name, at: Date.now() }); save(); return { ok: 1 };
  }
  if (k === 'GET notes') {
    need('teacher', 'student', 'school');
    if (u.role === 'student') {
      const ok = (u.sub || 0) > Date.now();
      return { subscribed: ok, price: SUB_PRICE, items: db.n.filter(x => x.schoolId === sid && x.cls === u.cls).map(x => ({ ...x, content: ok ? x.content : null, files: ok ? x.files : [] })) };
    }
    return { items: db.n.filter(x => x.schoolId === sid && taught(x.cls)) };
  }
  if (k === 'GET note-file') { // the paywall has to hold here too: a file id alone must not open a paid note
    need('teacher', 'student', 'school');
    const fid = q.get('id'), n = db.n.find(x => x.schoolId === sid && (x.files || []).some(v => v.id === fid));
    if (!n) E(404, 'File not found');
    if (!taught(n.cls)) E(403, 'You do not teach this class');
    if (u.role === 'student' && (n.cls !== u.cls || !((u.sub || 0) > Date.now()))) E(403, 'Subscribe to open this file');
    const f = n.files.find(v => v.id === fid);
    return { type: f.type, data: `data:${f.type};base64,${fs.readFileSync(path.join(NOTE_DIR, f.id)).toString('base64')}` };
  }
  if (k === 'POST subscribe') { need('student'); u.sub = Math.max(u.sub || 0, Date.now()) + SUB_DAYS * 864e5; save(); return self(u); } // demo: plug a payment gateway here

  // ---- results ----
  if (k === 'POST results') {
    need('school', 'teacher'); mine(b.studentId);
    if (!b.exam || !b.subject) E(400, 'Fill all fields');
    if (!(+b.total > 0 && +b.marks >= 0 && +b.marks <= +b.total)) E(400, 'Marks must be between 0 and the total');
    db.r.push({ id: id(), schoolId: sid, studentId: b.studentId, exam: b.exam, subject: b.subject, marks: +b.marks, total: +b.total }); save(); return { ok: 1 };
  }
  if (k === 'GET results') {
    need('school', 'teacher', 'student');
    return (u.role === 'student' ? db.r.filter(x => x.studentId === u.id) : db.r.filter(x => x.schoolId === sid && sees(x))).map(x => ({ ...x, student: nameOf(x) }));
  }

  // ---- monthly attendance ----
  if (k === 'POST attendance') {
    need('school', 'teacher'); mine(b.studentId);
    setDay(sid, b.studentId, b.month, b.day, b.present);
    save(); return { ok: 1 };
  }
  if (k === 'POST attendance-day') { // the class register: one date, every student in the class
    need('school', 'teacher');
    const [, month, day] = /^(\d{4}-\d{2})-(\d{2})$/.exec(b.date) || E(400, 'Choose a valid date');
    const on = new Set(b.present || []), c = cleanCls(b.cls, sid);
    if (!taught(c)) E(403, 'You do not teach this class');
    db.u.filter(v => v.schoolId === sid && v.role === 'student' && v.cls === c).forEach(s => setDay(sid, s.id, month, +day, on.has(s.id)));
    save(); return { ok: 1 };
  }
  if (k === 'GET attendance') {
    need('school', 'teacher', 'student');
    return (u.role === 'student' ? db.a.filter(x => x.studentId === u.id) : db.a.filter(x => x.schoolId === sid && sees(x))).map(x => ({ ...x, days: x.days || [], student: nameOf(x) }));
  }

  // ---- student documents (govt IDs etc.) ----
  if (k === 'POST docs') {
    need('school'); mine(b.studentId);
    if (!b.type || !b.photoData) E(400, 'Choose a document type and upload a photo');
    const match = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/.exec(b.photoData);
    if (!match) E(400, 'Photo must be JPG, PNG or WebP');
    if (Buffer.from(match[2], 'base64').length > 3 * 1024 * 1024) E(400, 'Photo must be 3 MB or smaller');
    db.d.push({ id: id(), schoolId: sid, studentId: b.studentId, type: b.type, photoData: b.photoData });
    saveDocs(db.s.find(v => v.id === sid)); return { ok: 1 };
  }
  if (k === 'GET docs') {
    need('school', 'student');
    return (u.role === 'student' ? db.d.filter(x => x.studentId === u.id) : db.d.filter(x => x.schoolId === sid)).map(x => ({ ...x, student: nameOf(x) }));
  }

  // ---- fees / payments ----
  if (k === 'POST fees') { need('school'); if (!b.title || !(+b.amount > 0) || !b.dueDate) E(400, 'Enter a title, an amount above 0 and a last date'); db.f.push({ id: id(), schoolId: sid, title: b.title, amount: +b.amount, dueDate: b.dueDate }); save(); return { ok: 1 }; }
  if (k === 'GET fees') {
    need('school', 'student');
    return db.f.filter(x => x.schoolId === sid).map(x => u.role === 'student' ? { ...x, paid: db.p.some(y => y.s === u.id && y.f === x.id) } : { ...x, paidBy: db.p.filter(y => y.f === x.id).map(y => y.s), paidAt: Object.fromEntries(db.p.filter(y => y.f === x.id).map(y => [y.s, y.at])), paidCount: db.p.filter(y => y.f === x.id).length });
  }
  if (k === 'POST pay') {
    need('student'); const f = db.f.find(x => x.id === b.feeId && x.schoolId === sid); if (!f) E(404, 'Fee not found');
    if (!db.p.some(y => y.s === u.id && y.f === f.id)) { db.p.push({ s: u.id, f: f.id, at: Date.now() }); save(); } return { ok: 1 };
  }
  E(404, 'Not found');
}

// HTTPS: either this server holds the certificate (TLS_KEY_FILE, TLS_CERT_FILE), or the hosting service does and sets x-forwarded-proto (TRUST_PROXY=1)
const TLS = process.env.TLS_KEY_FILE && process.env.TLS_CERT_FILE && { key: fs.readFileSync(process.env.TLS_KEY_FILE), cert: fs.readFileSync(process.env.TLS_CERT_FILE) };
const PROXY = process.env.TRUST_PROXY === '1';
const toHttps = (req, res) => {
  const port = !TLS || +PORT === 443 ? '' : ':' + PORT;
  res.writeHead(308, { Location: `https://${req.headers.host.replace(/:\d+$/, '')}${port}${req.url}` });
  res.end();
};
const app = (req, res) => {
  const secure = TLS || String(req.headers['x-forwarded-proto']).split(',')[0].trim() === 'https';
  if (PROXY && !secure) return toHttps(req, res);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  if (PROXY || TLS) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
  const url = new URL(req.url, 'http://x'); let body = '';
  const isNotes = url.pathname === '/api/notes', max = (isNotes ? 15 : 5) * 1024 * 1024; // 10 MB of note files is about 13.4 MB as base64
  req.on('data', d => {
    body += d;
    if (body.length > max) { res.writeHead(413, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: isNotes ? 'Request too large. Keep files within 10 MB in total.' : 'Request too large. Choose an image under 3 MB.' })); req.destroy(); }
  });
  req.on('end', () => {
    if (url.pathname === '/logo.png') { res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'max-age=86400' }); return res.end(fs.readFileSync(path.join(__dirname, 'logo.png'))); }
    if (!url.pathname.startsWith('/api/')) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(fs.readFileSync(path.join(__dirname, 'index.html'))); }
    const send = (c, o) => { res.writeHead(c, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(o)); };
    try {
      const u = db.u.find(x => x.id === sess[req.headers.authorization]);
      send(200, handle(req.method, url.pathname.slice(5), url.searchParams, body ? JSON.parse(body) : {}, u));
    } catch (e) { send(e.c || 400, { error: e.m || e.message }); }
  });
};
const started = () => console.log(`Running on ${TLS ? 'https' : 'http'}://localhost:${PORT}` + (TLS || PROXY ? '' : '\nHTTPS is OFF: use this for local testing only, see README.txt') + (mailer ? '' : '\nEmail is NOT configured: see .env.example'));
if (TLS) {
  https.createServer(TLS, app).listen(PORT, started);
  if (process.env.HTTP_PORT) http.createServer(toHttps).listen(process.env.HTTP_PORT); // sends plain http visitors to https
} else http.createServer(app).listen(PORT, started);
