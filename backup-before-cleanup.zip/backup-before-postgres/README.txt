ONERA WEBSITE — FIXED PROJECT

IMPORTANT: This website has a frontend AND a Node.js backend. Uploading index.html alone to Tiiny.site or another static HTML host will NOT make the login/API work. The backend must run on a Node.js host.

LOCAL WINDOWS TEST
1. Install Node.js LTS from https://nodejs.org
2. Extract this ONERA folder.
3. Open the ONERA folder in VS Code using File > Open Folder.
4. Choose Terminal > New Terminal.
5. Run: npm install
6. Run: npm start
   (or: node server.js)
7. Keep the terminal running.
8. Open http://localhost:3000 — do not use Live Server port 5500 and do not open index.html directly.

FORGOT USERNAME / PASSWORD EMAILS
1. Copy .env.example to .env and fill in the mail account. Gmail needs an App Password. On a hosting service, set these as environment variables instead of using .env.
2. Restart the server.
Forgot username and forgot password both email a 6-digit code that expires in 10 minutes and allows 5 tries. Each user needs a saved email: fill it in on the Profile page, or when creating the account. A student's password code goes to their school admin's email, and the admin passes it on; if the school admin has no saved email, it goes to the student's own email instead. Until mail is configured, messages (including codes) are printed in the server terminal instead of being sent. Never commit .env.

DEFAULT DEMO ADMIN
Username: admin
Password: admin123
Change/remove this demo password before public use.

DEPLOY ONLINE
Deploy the entire ONERA folder/repository to a Node.js hosting service. Build command: npm install; start command: npm start. The service must run server.js and serve index.html from the same origin. Do not deploy only index.html to Tiiny.site. If using a separate static frontend, its API URL must point to the deployed backend and the backend must allow that frontend origin.

DATABASE WARNING
This starter project uses db.json for demonstration. For 15,000–20,000 students and real school records, migrate to PostgreSQL and configure persistent storage/backups, strong admin credentials, secure document storage, and access controls before production. Do not store real student certificates in a public demo.

SCHOOL DOCUMENT FILES
Each school or college has its own file in the school-data folder, named after the institution (for example TIPS-09cca5bd59.json), holding all its uploaded documents. Everything else stays in db.json. These files contain ID photos: back them up together with db.json, and never commit or share them.

CLASS SECTIONS
Schools run classes 1 to 10 with sections A, B and C (for example 5-A). Colleges keep semesters 1 to 8 without sections. Records from before sections were added are moved once when the server starts: students and notes go to section A, teachers get all three sections of their classes, and the old data is saved as db.json.before-sections.

TIMETABLE AND HOMEWORK
The school admin builds each class's timetable under Timetable; a class or teacher cannot get two periods at the same time. Teachers see the timetable of the classes they teach, and students see only their own class. Teachers give homework to their own classes with a due date, and students see only their own class's homework. School admins can see and delete all of it. Homework is free, unlike notes.

YEARLY PROMOTION
On 1 April the server moves every school student up one class in the same section (5-A goes to 6-A). Class 10 students become "Passed out": they keep their login and records, and can be found under Show > Passed out in People. If the server is off on 1 April, this runs the next time it starts. Colleges and teachers' classes do not change. The data from just before is saved as db.json.before-promotion-YEAR, and db.json remembers the last year done in "promoted".

PROFILES
Every login has a Profile page for personal, family and contact details. School admins can also open the profile of their own teachers and students from People. Teachers cannot see student profiles and the main admin cannot see anyone else's.

ENCRYPTION
db.json and the school-data files (profiles, photos, Aadhaar and other ID documents, marks, emails) are encrypted on disk with AES-256-GCM using DATA_KEY, and the server will not start without it. Copies the server makes by itself (db.json.before-*) are encrypted too. Files in note-files are study material and are not encrypted, so do not attach personal documents to notes.
Keep a copy of DATA_KEY in a password manager or on paper, not in this folder: if it is lost, the data cannot be recovered by anyone. On a hosting service, set it as an environment variable. Back up db.json and school-data together with the key's safe copy, but never store them side by side.

HTTPS
Without HTTPS, passwords and ID photos travel over the internet readable. Plain http is fine only for testing on localhost; the server prints a warning in that case. For real use, pick one:
1. Host with built-in HTTPS (Render, Railway and similar): set TRUST_PROXY=1 and DATA_KEY in the host's environment settings. Every http visit is sent to https.
2. Your own server: get a free certificate for your domain from Let's Encrypt, then set TLS_KEY_FILE, TLS_CERT_FILE, PORT=443 and HTTP_PORT=80. Restart the server after each certificate renewal.
Do not set TRUST_PROXY=1 on a plain local run: every page would redirect to an https address that is not there.

NOTE FILES
PDFs and images that teachers attach to notes are kept in the note-files folder; db.json only stores their names. Back this folder up together with db.json.

PAYMENTS
The current payment/subscribe actions are demonstrations only; they do not process real money.
